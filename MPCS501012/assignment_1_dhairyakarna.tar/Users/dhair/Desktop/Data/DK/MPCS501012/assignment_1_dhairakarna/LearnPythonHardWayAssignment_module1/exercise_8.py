formatter = "{} {} {} {}"

#passing the given values in the variable formatter and then printing it
#if there are no values it will simply print it as a string
print(formatter)
print(formatter.format(1, 2, 3, 4))
print(formatter.format("one", "two", "three", "four"))
print(formatter.format(True, False, False, True))
print(formatter.format(formatter, formatter, formatter, formatter))
print(formatter.format(
    "Try your",
    "Own text here",
    "Maybe a poem",
    "Or a song about fear"
))