print("Mary had a little lamb.") #prints the given values
print("Its fleece was white as {}.".format('snow')) #use of .format function to pass another value
print("And everywhere that Mary went.") #prints the given values
print("." * 10)  #prints the string 10 times

end1 = "C"
end2 = "h"
end3 = "e"
end4 = "e"
end5 = "s"
end6 = "e"
end7 = "B"
end8 = "u"
end9 = "r"
end10 = "g"
end11 = "e"
end12 = "r"

# removing end = ' ' removes the space at the end of the string
print(end1 + end2 + end3 + end4 + end5 + end6, end='')
print(end7 + end8 + end9 + end10 + end11 + end12)